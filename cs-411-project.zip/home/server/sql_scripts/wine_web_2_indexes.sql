CREATE INDEX review_username 
ON wine_web_2.reviews(username);

CREATE INDEX review_points 
ON wine_web_2.reviews(points);